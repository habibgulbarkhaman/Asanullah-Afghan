package com.ehsanullahafghan.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.provider.OpenableColumns;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP = 4101;
    private static final int OPEN_BACKUP = 4102;
    private WebView webView;
    private String pendingBackupJson = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class BackupBridge {
        @JavascriptInterface public void saveBackup(String json) {
            pendingBackupJson = json == null ? "" : json;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "Ehsanullah-Afghan-Backup.json");
                startActivityForResult(intent, CREATE_BACKUP);
            });
        }

        @JavascriptInterface public void openBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json"});
                startActivityForResult(intent, OPEN_BACKUP);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == CREATE_BACKUP) callJs("window.onNativeBackupSaved(false,'Cancelled');");
            return;
        }
        Uri uri = data.getData();
        if (requestCode == CREATE_BACKUP) {
            boolean success = false;
            String message = "Save failed";
            try (OutputStream out = getContentResolver().openOutputStream(uri);
                 Writer writer = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {
                writer.write(pendingBackupJson);
                writer.flush();
                success = true;
                message = getDisplayName(uri);
            } catch (Exception ex) { message = ex.getMessage() == null ? "Save failed" : ex.getMessage(); }
            final boolean ok = success;
            final String msg = jsQuote(message);
            callJs("window.onNativeBackupSaved(" + ok + "," + msg + ");");
        } else if (requestCode == OPEN_BACKUP) {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                StringBuilder content = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) content.append(line).append('\n');
                callJs("window.onNativeBackupLoaded(" + jsQuote(content.toString()) + ");");
            } catch (Exception ex) {
                callJs("window.onNativeBackupLoaded('');");
            }
        }
    }

    private String getDisplayName(Uri uri) {
        try (android.database.Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {}
        return "Ehsanullah-Afghan-Backup.json";
    }

    private String jsQuote(String value) {
        return org.json.JSONObject.quote(value == null ? "" : value);
    }

    private void callJs(String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }
}
